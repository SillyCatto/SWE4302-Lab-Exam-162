package tax;

public interface ITax {
    double getTax(double basePrice);
}
