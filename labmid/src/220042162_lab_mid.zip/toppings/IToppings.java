package toppings;

public interface IToppings {
    double getPrice();
}
