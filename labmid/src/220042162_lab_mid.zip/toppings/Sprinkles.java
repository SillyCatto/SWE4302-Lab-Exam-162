package toppings;

public class Sprinkles implements IToppings{
    @Override
    public double getPrice() {
        return 0.30;
    }
}
