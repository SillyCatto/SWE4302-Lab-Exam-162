package toppings;

public class FreshStrawberries implements IToppings{
    @Override
    public double getPrice() {
        return 1.00;
    }
}
