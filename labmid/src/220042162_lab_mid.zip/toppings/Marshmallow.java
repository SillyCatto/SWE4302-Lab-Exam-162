package toppings;

public class Marshmallow implements IToppings{
    @Override
    public double getPrice() {
        return 0.70;
    }
}
