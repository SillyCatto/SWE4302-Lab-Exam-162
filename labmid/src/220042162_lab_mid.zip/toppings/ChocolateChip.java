package toppings;

public class ChocolateChip implements IToppings{
    @Override
    public double getPrice() {
        return 0.5;
    }
}
