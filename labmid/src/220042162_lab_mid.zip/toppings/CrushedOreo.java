package toppings;

public class CrushedOreo implements IToppings{
    @Override
    public double getPrice() {
        return 0.85;
    }
}
