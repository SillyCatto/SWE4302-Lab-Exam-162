package flavors;

public class StrawberrySwirl implements IFlavor{

    @Override
    public double getPricePerScoop() {
        return 2.75;
    }
}
