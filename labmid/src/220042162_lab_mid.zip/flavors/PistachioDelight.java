package flavors;

public class PistachioDelight implements IFlavor{

    @Override
    public double getPricePerScoop() {
        return 3.25;
    }
}
