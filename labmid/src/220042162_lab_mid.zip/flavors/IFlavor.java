package flavors;

public interface IFlavor {
    double getPricePerScoop();
}
