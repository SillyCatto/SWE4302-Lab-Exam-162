package flavors;

public class MintChocolateChip implements IFlavor{

    @Override
    public double getPricePerScoop() {
        return 2.80;
    }
}
