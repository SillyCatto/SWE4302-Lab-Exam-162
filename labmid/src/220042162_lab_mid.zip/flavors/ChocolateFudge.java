package flavors;

public class ChocolateFudge implements IFlavor{

    @Override
    public double getPricePerScoop() {
        return 3.00;
    }
}
