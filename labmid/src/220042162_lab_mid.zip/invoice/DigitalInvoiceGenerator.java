package invoice;

import order.Order;

public class DigitalInvoiceGenerator implements IInvoiceMaker{
    @Override
    public void generateInvoice(Order order) {

    }
}
