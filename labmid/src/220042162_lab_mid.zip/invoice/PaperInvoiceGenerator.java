package invoice;

import order.Order;

public class PaperInvoiceGenerator implements IInvoiceMaker{

    @Override
    public void generateInvoice(Order order) {

    }
}
