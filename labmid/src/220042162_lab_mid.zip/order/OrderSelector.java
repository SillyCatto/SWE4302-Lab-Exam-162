package order;

import container.IContainer;
import flavors.IFlavor;
import toppings.IToppings;

public class OrderSelector {
    static IFlavor flavorSelector(){
        // select order type based on user input
        return null; // dummy place holder value
    }

    static IToppings toppingsSelector(){
        // select toppings type based on user input
        return null; // dummy place holder value
    }

    static IContainer containerSelector(){
        // select container type - paper cup or waffle cone based on
        // user input
        return null;
    }
}
