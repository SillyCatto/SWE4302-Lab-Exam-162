package container;

public class PaperCup implements IContainer {
    @Override
    public double getPrice() {
        return 0;
    }
}
