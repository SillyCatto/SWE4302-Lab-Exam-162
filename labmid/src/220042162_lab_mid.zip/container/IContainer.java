package container;

public interface IContainer {
    double getPrice();
}
