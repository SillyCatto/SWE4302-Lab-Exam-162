package container;

public class WaffleCone implements IContainer {
    @Override
    public double getPrice() {
        return 5.00;
    }
}
